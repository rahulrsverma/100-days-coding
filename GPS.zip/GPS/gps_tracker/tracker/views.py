# tracker/views.py
from rest_framework.response import Response
from rest_framework import status
from rest_framework.decorators import api_view
from .models import GPSData
from .serializers import GPSDataSerializer

@api_view(['POST'])
def save_gps_data(request):
    serializer = GPSDataSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()  # Save to SQLite database
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
@api_view(['GET'])
def get_gps_data(request):
    gps_data = GPSData.objects.all().order_by('-timestamp')  # Get all GPS records
    serializer = GPSDataSerializer(gps_data, many=True)
    return Response(serializer.data)