# tracker/urls.py
from django.urls import path
from .views import save_gps_data
from .views import get_gps_data

urlpatterns = [
    path('save-gps/', save_gps_data, name='save_gps'),
    path('get-gps/', get_gps_data, name='get_gps'),
]
