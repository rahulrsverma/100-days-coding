from django.contrib import admin
from .models import GPSData

admin.site.register(GPSData)
