# tracker/models.py
from django.db import models

class GPSData(models.Model):
    vehicle_number = models.CharField(max_length=20)
    latitude = models.FloatField()
    longitude = models.FloatField()
    speed = models.FloatField()
    course = models.FloatField()
    timestamp = models.DateTimeField(auto_now_add=True)  # Auto-set the timestamp
    ignition_status = models.BooleanField(default=False)
    unique_id = models.CharField(max_length=50, blank=True, null=True)
    altitude = models.FloatField()

    def __str__(self):
        return f"{self.vehicle_number} - {self.timestamp}"
